package finalpaint.finalpaint__letshope__;


import javafx.scene.canvas.Canvas;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;

public class FunctionalCanvas extends CanvasTools {
private double xCord;
private double yCord;
private Image cAp;      //Copy and Paste




    public FunctionalCanvas(){
        super();
        this.setHeight(900);
        this.setWidth(1600);
        this.setFillColor(Color.WHITE);
        this.setLineColor(Color.WHITE);
        this.setFillShape(true);
        this.drawingRect(0,0,this.getWidth(), this.getHeight());
        this.setFillShape(false);


        this.setOnMousePressed(e->{
            xCord = e.getX();
            yCord = e.getY();
            this.setFillColor(MenuForCanvTools.getFillColor());
            this.setLineColor(MenuForCanvTools.getLineColor());
            this.setLineWidth(MenuForCanvTools.getLineWidth());
            this.setFillShape(MenuForCanvTools.getFillStatus());
                switch(MenuForCanvTools.currTool()){
                    case("Eraser"):
                        this.setLineColor(Color.WHITE);
                        break;

                    case("Line"):
                        this.drawingLine(xCord,yCord,xCord,yCord);
                        break;

                    case("Rectangle"):
                        this.drawingRect(xCord,yCord,xCord,yCord);
                        break;

                    case("Square"):
                        this.drawingSquare(xCord, yCord, xCord, yCord);
                        break;

                    case("Ellipse"):
                        this.drawingEllipse(xCord, yCord, xCord, yCord);
                        break;

                    case("Circle"):
                        this.drawingCircle(xCord, yCord, xCord, yCord, 314);
                        break;

                    case("Multi-gon"):
                        this.drawingCrazyGon(xCord, yCord, xCord, yCord, 8);
                        break;

                    case("Eeydropper"):
                        MenuForCanvTools.setLineColor(this.getPixCol(xCord, yCord));
                        MenuForCanvTools.setFillColor((this.getPixCol(xCord, yCord)));
                        break;

                    case("Copy"):
                        this.setLineWidth(2);
                        this.setLineColor(Color.BLACK);
                        this.drawingRect(xCord,yCord,xCord,yCord);
                        this.setFillShape(false);
                        break;

                    case("Paste"):
                        this.drawImageAt(cAp, e.getX(), e.getY());
                        break;

                    case("Cut"):
                        this.setLineWidth(2);
                        this.setLineColor(Color.BLACK);
                        this.drawingRect(xCord,yCord,xCord,yCord);
                        this.setFillShape(false);
                        break;
                }
            });
        this.setOnMouseDragged(e->{
            switch(MenuForCanvTools.currTool()){
                case("Free Draw"):
                    this.drawingLine(xCord, yCord, e.getX(), e.getY());
                    xCord = e.getX();
                    yCord = e.getY();
                    break;
                case("Eraser"):
                    this.drawingLine(xCord, yCord, e.getX(), e.getY());
                    xCord = e.getX();
                    yCord = e.getY();
                    break;
                case("Line"):
                    this.drawingLine(xCord,yCord, e.getX(), e.getY());
                    break;
                case("Rectangle"):
                    this.drawingRect(xCord,yCord,e.getX(),e.getY());
                    break;
                case("Square"):
                    this.drawingSquare(xCord, yCord, e.getX(), e.getY());
                    break;
                case("Ellipse"):
                    this.drawingEllipse(xCord, yCord, e.getX(), e.getY());
                    break;
                case("Circle"):
                    this.drawingCircle(xCord, yCord, e.getX(), e.getY(), 314);
                    break;
                case("Multi-gon"):
                    this.drawingCrazyGon(xCord, yCord, e.getX(), e.getY(), MenuForCanvTools.pGonSides());
                    break;
                case("Eeydropper"):
                    MenuForCanvTools.setLineColor(this.getPixCol(e.getX(), e.getY()));
                    MenuForCanvTools.setFillColor((this.getPixCol(e.getX(), e.getY())));
                    break;
                case("Copy"):
                    this.setLineWidth(2);
                    //this.setLineColor(Color.BLACK);
                    this.drawingRect(xCord,yCord,e.getX(),e.getY());
                    //this.setFillShape(false);
                    break;
                case("Paste"):
                    this.drawImageAt(cAp, e.getX(), e.getY());
                    break;
                case("Cut"):
                    //this.setLineWidth(3);
                    //this.setLineColor(Color.BLACK);
                    this.drawingRect(xCord,yCord,e.getX(),e.getY());
                    //this.setFillShape(false);
                    break;
            }
        });


        this.setOnMouseReleased(e->{
            switch(MenuForCanvTools.currTool()){
                case("Free Draw"):
                    this.drawingLine(xCord, yCord, e.getX(), e.getY());
                    break;
                case("Eraser"):
                    this.drawingLine(xCord, yCord, e.getX(), e.getY());
                    break;
                case("Line"):
                    this.drawingLine(xCord,yCord,e.getX(),e.getY());
                    break;
                case("Rectangle"):
                    this.drawingRect(xCord,yCord,e.getX(),e.getY());
                    break;
                case("Square"):
                    this.drawingSquare(xCord, yCord, e.getX(), e.getY());
                    break;
                case("Ellipse"):
                    this.drawingEllipse(xCord, yCord, e.getX(), e.getY());
                    break;
                case("Circle"):
                    this.drawingCrazyGon(xCord, yCord, e.getX(), e.getY(), 314);
                    break;
                case("Multi-gon"):
                    this.drawingCrazyGon(xCord, yCord, e.getX(), e.getY(), MenuForCanvTools.pGonSides());
                    break;
                case("Eeydropper"):
                    MenuForCanvTools.setLineColor(this.getPixCol(xCord, yCord));
                    MenuForCanvTools.setFillColor((this.getPixCol(xCord, yCord)));
                    break;
                case("Copy"):
                    this.cAp = this.getArea(xCord, yCord,e.getX(), e.getY());
                    break;
                case("Paste"):
                    if(this.cAp != null) {
                        this.drawImageAt(cAp, e.getX(), e.getY());
                    }
                    break;
                case("Cut"):
                    this.cAp = this.getArea(xCord, yCord, e.getX(), e.getY());
                    this.setFillShape(true);
                    this.setLineColor(MenuForCanvTools.getFillColor());
                    this.setLineWidth(2);
                    this.drawingRect(xCord, yCord, e.getX(), e.getY());
                    break;
            }
        });
    }
}