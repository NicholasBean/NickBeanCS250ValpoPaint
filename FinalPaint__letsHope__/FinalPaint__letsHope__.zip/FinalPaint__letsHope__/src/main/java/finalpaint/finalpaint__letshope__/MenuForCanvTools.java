package finalpaint.finalpaint__letshope__;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.scene.control.*;
import javafx.scene.paint.Color;

public class MenuForCanvTools extends ToolBar{
    private static ColorPicker fillCP;
    private static ColorPicker lineCP;
    private static CheckBox setFill;
    private static int currWidth;
    private static int currTool;
    private static ComboBox<Integer> WidthBox;
    private static ComboBox<String> DrawTool;
    private static int nSidePoly;
    private static TextField sideNum;
    private final static String[] dTools = {"None", "Eraser", "Line", "Free Draw", "Rectangle",
            "Square", "Ellipse", "Circle", "Multi-gon", "Eyedropper", "Cut", "Copy", "Paste"
    };
    private final static Integer[] dWidth = {2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 25, 50, 75, 100, 200};

    public MenuForCanvTools(){
        super();
        currWidth = 1;
        currTool = 0;
        nSidePoly = 8;

        WidthBox = new ComboBox<>(FXCollections.observableArrayList(dWidth));
        DrawTool = new ComboBox<>(FXCollections.observableArrayList(dTools));

        sideNum = new TextField("8");
        fillCP = new ColorPicker();
        lineCP = new ColorPicker();
        setFill = new CheckBox();

        Label canv_tools = new Label("Canvas Tools");
        Label line_color = new Label("Line Color");
        Label fill_color = new Label("Fill Color");
        Label line_width = new Label("Line Width");
        Label fill = new Label("Fill");
        getItems().addAll(
                canv_tools, DrawTool, sideNum, new Separator(),
                line_color, lineCP,
                fill_color, fillCP, new Separator(),
                line_width, WidthBox, new Separator(),
                fill, setFill
        );

        lineCP.setValue(Color.BLACK);
        fillCP.setValue(Color.WHITE);
        DrawTool.setValue("None");
        WidthBox.setEditable(true);
        WidthBox.setPrefWidth(75);
        WidthBox.setValue(1);
        sideNum.setPrefWidth(45);


        DrawTool.getSelectionModel().selectedIndexProperty().addListener((observable, val, newVal) ->{
            currTool = newVal.intValue();
            if(dTools[currTool].equals("Multi-gon")){
                sideNum.setVisible(true);
            }
            else{
                sideNum.setVisible(false);
            }
        });
        WidthBox.getEditor().focusedProperty().addListener((obs, wasFoc, isFoc) -> {
            if(isFoc){
                if(Integer.parseInt(WidthBox.getEditor().getText()) >= 1 ) {
                    WidthBox.setValue(Integer.parseInt(WidthBox.getEditor().getText()));
                    }
                else{
                    WidthBox.setValue(0);
                }
            }
        });
        WidthBox.setOnAction((ActionEvent e) ->{
            currWidth = WidthBox.getValue();
        });
        sideNum.textProperty().addListener((observable, val, newVal) -> {
            if(Integer.parseInt(newVal) >= 3){
                nSidePoly = Integer.parseInt(newVal);
            }
            else{
                sideNum.setText("3");
            }
        });

        switch(MenuForCanvTools.currTool()) {
            case("Eraser"):
                Tooltip eraserTip = new Tooltip("Erases and clears up any mistakes.");
                DrawTool.setTooltip(eraserTip);
                break;

            case("Line"):
                Tooltip lineTip = new Tooltip("Click and drag for a straight line.");
                DrawTool.setTooltip(lineTip);
                break;

            case("Rectangle"):
                Tooltip rectTip = new Tooltip("Click and drag for a rectangle.");
                DrawTool.setTooltip(rectTip);
                break;

            case("Square"):
                Tooltip squareTip = new Tooltip("Click and drag for a square.");
                DrawTool.setTooltip(squareTip);
                break;

            case("Ellipse"):
                Tooltip EllTip = new Tooltip("Click and drag for an ellipse");
                DrawTool.setTooltip(EllTip);
                break;

            case("Circle"):
                Tooltip circTip = new Tooltip("Click and drag for a circle.");
                DrawTool.setTooltip(circTip);
                break;

            case("Multi-gon"):
                Tooltip nGonTip = new Tooltip("Click and drag for a multi-sided polygon");
                DrawTool.setTooltip(nGonTip);
                break;

            case("Eeydropper"):
                Tooltip eyeTip = new Tooltip("Click for a particular pixel color.");
                DrawTool.setTooltip(eyeTip);
                break;

            case("Copy"):
                Tooltip copyTip = new Tooltip("Click and drag to copy a part of your canvas.");
                DrawTool.setTooltip(copyTip);
                break;

            case("Paste"):
                Tooltip pasteTip = new Tooltip("Click to paste the copied image.");
                DrawTool.setTooltip(pasteTip);
                break;

            case("Cut"):
                Tooltip cutTip = new Tooltip("Click and drag to select part of your canvas. This will be deleted once released.");
                DrawTool.setTooltip(cutTip);
                break;
        }

    }


    public static int pGonSides(){return nSidePoly;}
    public static void setLineColor(Color color){ lineCP.setValue(color);}
    public static Color getLineColor(){return lineCP.getValue();}
    public static void setFillColor(Color color){fillCP.setValue(color);}
    public static Color getFillColor(){return fillCP.getValue();}
    public static int getLineWidth(){ return currWidth;}
    public static boolean getFillStatus(){return setFill.isSelected();}
    public static String currTool(){return dTools[currTool];}

}