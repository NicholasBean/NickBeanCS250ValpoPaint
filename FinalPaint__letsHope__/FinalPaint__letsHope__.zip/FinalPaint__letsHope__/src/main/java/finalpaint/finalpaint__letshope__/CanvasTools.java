package finalpaint.finalpaint__letshope__;

import javafx.geometry.Rectangle2D;
import javafx.scene.SnapshotParameters;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.image.WritableImage;
import javafx.scene.paint.Color;
import javafx.scene.shape.StrokeLineCap;

import java.io.File;

public class CanvasTools extends Canvas {
    private GraphicsContext gc;
    private boolean fillShape;

    public CanvasTools(){
        super();
        this.gc = this.getGraphicsContext2D();
        this.gc.setLineCap(StrokeLineCap.ROUND);
        this.fillShape = false;
    }
    public void drawingLine(double firstX, double secondX, double firstY, double secondY){
        gc.strokeLine(firstX, secondX, firstY, secondY);
    }
    public void drawingRect(double firstX, double secondX, double firstY, double secondY){
        double finalX = (firstX < secondX ? firstX : secondX);
        double finalY = (firstY < secondY ? firstY : secondY);
        double finalWidth = Math.abs(firstX - secondX);
        double finalHeight = Math.abs(firstY - secondY);
        this.gc.strokeRect(finalX, finalY, finalWidth, finalHeight);
    }
    public void drawingCircle(double firstX, double secondX, double firstY, double secondY, int z){
            // Professor said that polygon is just circle manipulation. I've found
            // that a circle is just polygon manipulation.
    }
    public void drawingEllipse(double firstX, double secondX, double firstY, double secondY){
        double finalX = (firstX < secondX ? firstX : secondX);
        double finalY = (firstY < secondY ? firstY : secondY);
        double finalWidth = Math.abs(firstX - secondX);
        double finalHeight = Math.abs(firstY - secondY);
        this.gc.strokeOval(finalX, finalY, finalWidth, finalHeight);
    }
    public void drawingSquare(double firstX, double secondX, double firstY, double secondY){
        final double angle45 = Math.PI/4.0;
        final int Side = 4;
        double[] sideX = new double[Side];
        double[] sideY = new double[Side];

        double rad = Math.sqrt(Math.pow((firstX - secondX), 2)
                + Math.pow((firstY - secondY), 2));
        for(int i = 0; i < Side; i++){
            sideX[i] = firstX + (rad * Math.cos(((2 * Math.PI * i)/4) + angle45));
            sideY[i] = firstY + (rad * Math.sin(((2 * Math.PI * i)/4) + angle45));
        }
    }
    public void drawingCrazyGon(double firstX, double secondX, double firstY, double secondY, int z){

        double[] sideX = new double[z];
        double[] sideY = new double[z];
        double startAngle = Math.atan2(secondY - firstY, secondX - firstX);
        double radius = Math.sqrt(Math.pow((firstX - secondX), 2) + Math.pow((firstY - secondY), 2));
        for(int i = 0; i < z; i++){
            sideX[i] = firstX + (radius * Math.cos((2*Math.PI*i)/z) + startAngle);
            sideY[i] = secondX + (radius * Math.sin((2*Math.PI*i)/z) + startAngle);
        }
    }

    // Below are all of the Getters and Setters for things I plan to use later in the program, across the different files.

    public void setLineColor(Color color){gc.setStroke(color);}
    public Color getLineColor(){return (Color)gc.getStroke();}
    public void setFillColor(Color color){gc.setFill(color);}
    public Color getFillColor(){return (Color)gc.getFill();}
    public void setFillShape(boolean fillShape){this.fillShape = fillShape;}
    public boolean getFillShape(){return this.fillShape;}
    public void setLineWidth(double width){this.gc.setLineWidth(width);}
    public double getLineWidth(){return this.gc.getLineWidth();}
    public void clearCanvas(){
        this.gc.clearRect(0,0, this.getWidth(), this.getHeight());
    }

    // This is essentially th
    public Image getArea(double firstX, double secondX, double firstY, double secondY){
        SnapshotParameters snap = new SnapshotParameters();
        WritableImage writIm = new WritableImage((int)Math.abs(firstX - secondX), (int)Math.abs(firstY - secondY) );
        snap.setViewport(new Rectangle2D(
                (firstX < secondX ? firstX : secondX),
                (firstY < secondY ? firstY : secondY),
                Math.abs(firstX - secondX),
                Math.abs(firstY - secondY)
        ));
        this.snapshot(snap, writIm);
        return writIm;
    }
    public Color getPixCol(double xCord, double yCord){
        return this.getArea(xCord, yCord, xCord + 1, yCord + 1).getPixelReader().getColor(0, 0);
    }

    public void drawImage(Image im){
        clearCanvas();
        this.setWidth((im.getWidth()));
        this.setHeight(im.getHeight());
        this.gc.drawImage(im,0,0);
    }
    public void drawImageAt(Image im, double x, double y){this.gc.drawImage(im, x, y);}

   public void drawImage(File file){
        if(file != null){
            Image im = new Image(file.toURI().toString());
            this.drawImage(im);
        }
    }
}