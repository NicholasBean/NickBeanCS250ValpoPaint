package finalpaint.finalpaint__letshope__;

import javafx.scene.control.Tab;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.StackPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javax.imageio.ImageIO;
import javafx.stage.Window;

import java.awt.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import javafx.embed.swing.SwingFXUtils;

public class TabConstruction extends Tab {
        public Pane canvasPane;
        private ScrollPane scrolling;
        private StackPane stackyCanvas;
        private FunctionalCanvas canvas;
        private String tabTitle;
        private static FileChooser chosenFile;
        private File route;
        private boolean canvChange;


        public TabConstruction(){
                super();
                this.route = null;
                this.canvas = new FunctionalCanvas();
                this.tabTitle = "New Tab";
                this.canvChange = true;
                develop();
        }
        public TabConstruction(File file){
                super();
                this.route = null;
                this.canvas = new FunctionalCanvas();
                this.tabTitle = route.getName();
                this.canvChange = true;
                develop();
        }
        private void develop(){

                this.canvasPane = new Pane(canvas);
                this.stackyCanvas = new StackPane();
                this.stackyCanvas.getChildren().addAll(canvasPane);
                this.scrolling = new ScrollPane(this.stackyCanvas);
                this.setContent(scrolling);


                this.scrolling.setPrefViewportHeight(this.canvas.getHeight()/2);
                this.scrolling.setPrefViewportWidth(this.canvas.getWidth()/2);
                this.setText(tabTitle);

                chosenFile = new FileChooser();
                chosenFile.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Png files (*.png)", "*.png"),
                new FileChooser.ExtensionFilter("Jpg files (*.jpg)", "*.jpg"),
                new FileChooser.ExtensionFilter("Bmp Files (*.bmp)", "*.bmp"));

        }

        public void drawImageAt(Image im, double x, double y){this.canvas.drawImageAt(im, x, y);}
        public void setFileRoute(File route){this.route = route;}
        public File getFileRoute(){return this.route;}
        public FunctionalCanvas getCanvas(){return this.canvas;}
        public double canvHeight() {return this.canvas.getHeight();}
        public double canvWidth() {return this.canvas.getWidth();}
        public void newTabName(){
                if(this.route != null)
                        this.tabTitle = this.route.getName();
                else
                        this.setText(this.tabTitle);
        }
        public void setTitle(String name) {this.tabTitle = tabTitle;}
        public String getTitle(){return this.tabTitle;}
        public void imageSaveAs(){
                File route = chosenFile.showSaveDialog(WindowBuild.TheStage);
                this.setFileRoute(route);
                this.saveImage();
        }
        public void saveImage(){
                Image heehee = this.canvas.getArea(0, 0, this.canvas.getWidth(), this.canvas.getHeight());
                try {
                        if (this.route != null) {
                                ImageIO.write(SwingFXUtils.fromFXImage(heehee, null), "png", this.route);
                                this.setTitle(this.getFileRoute().getName());
                        }
                }
                catch (IOException ex) {
                        System.out.println(ex.toString());
                }
        }
        public static void openImage(){
                File route = chosenFile.showOpenDialog(WindowBuild.TheStage);
                TabConstruction skunk;
                if(route == null)
                        skunk = new TabConstruction();
                else
                        skunk = new TabConstruction(route);
                skunk.canvas.drawImage(route);
                WindowBuild.newTab.getTabs().add(skunk);
                WindowBuild.newTab.getSelectionModel().select(skunk);
        }
        public static void openImage(File route){
                TabConstruction skunk;
                if(route == null)
                        skunk = new TabConstruction();
                else
                        skunk = new TabConstruction(route);
                skunk.canvas.drawImage(route);
                WindowBuild.newTab.getTabs().add(skunk);
                WindowBuild.newTab.getSelectionModel().select(skunk);
        }

        public static void openBlankImage(){
                TabConstruction chingle = new TabConstruction();
                WindowBuild.newTab.getTabs().add(chingle);
                WindowBuild.newTab.getSelectionModel().select(chingle);

        }

        public void exit(){

        }
}